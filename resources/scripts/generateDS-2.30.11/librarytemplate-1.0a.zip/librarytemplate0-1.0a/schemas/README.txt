
The {{schema_name}}lib.py module in this package was generated from
the XML schemas in this directory.



