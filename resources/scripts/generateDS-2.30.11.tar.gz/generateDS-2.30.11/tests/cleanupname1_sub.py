#!/usr/bin/env python

#
# Generated  by generateDS.py.
# Python 3.6.6 |Anaconda custom (64-bit)| (default, Oct  9 2018, 12:34:16)  [GCC 7.3.0]
#
# Command line options:
#   ('--no-dates', '')
#   ('--no-versions', '')
#   ('--silence', '')
#   ('--member-specs', 'list')
#   ('-f', '')
#   ('-o', 'tests/cleanupname2_sup.py')
#   ('-s', 'tests/cleanupname2_sub.py')
#   ('--super', 'cleanupname2_sup')
#   ('--cleanup-name-list', "[('[-:.]', '_'), ('^Type', 'Class'), ('Type$', 'Kind'), ('[ABC]', 'M'), ('[XYZ]', 'N'), ]")
#
# Command line arguments:
#   tests/cleanupname.xsd
#
# Command line:
#   generateDS.py --no-dates --no-versions --silence --member-specs="list" -f -o "tests/cleanupname2_sup.py" -s "tests/cleanupname2_sub.py" --super="cleanupname2_sup" --cleanup-name-list="[('[-:.]', '_'), ('^Type', 'Class'), ('Type$', 'Kind'), ('[ABC]', 'M'), ('[XYZ]', 'N'), ]" tests/cleanupname.xsd
#
# Current working directory (os.getcwd()):
#   generateds
#

import sys
from lxml import etree as etree_

import cleanupname2_sup as supermod

def parsexml_(infile, parser=None, **kwargs):
    if parser is None:
        # Use the lxml ElementTree compatible parser so that, e.g.,
        #   we ignore comments.
        parser = etree_.ETCompatXMLParser()
    doc = etree_.parse(infile, parser=parser, **kwargs)
    return doc

#
# Globals
#

ExternalEncoding = ''

#
# Data representation classes
#


class dataKindSub(supermod.dataKind):
    def __init__(self, data1=None, data2=None, data3=None, data4=None, data5=None, **kwargs_):
        super(dataKindSub, self).__init__(data1, data2, data3, data4, data5,  **kwargs_)
supermod.dataKind.subclass = dataKindSub
# end class dataKindSub


class data1KindSub(supermod.data1Kind):
    def __init__(self, content1=None, **kwargs_):
        super(data1KindSub, self).__init__(content1,  **kwargs_)
supermod.data1Kind.subclass = data1KindSub
# end class data1KindSub


class MlassData2Sub(supermod.MlassData2):
    def __init__(self, content1=None, **kwargs_):
        super(MlassData2Sub, self).__init__(content1,  **kwargs_)
supermod.MlassData2.subclass = MlassData2Sub
# end class MlassData2Sub


class RealTypeData3Sub(supermod.RealTypeData3):
    def __init__(self, content1=None, **kwargs_):
        super(RealTypeData3Sub, self).__init__(content1,  **kwargs_)
supermod.RealTypeData3.subclass = RealTypeData3Sub
# end class RealTypeData3Sub


class MMMMMMdataKindSub(supermod.MMMMMMdataKind):
    def __init__(self, content1=None, **kwargs_):
        super(MMMMMMdataKindSub, self).__init__(content1,  **kwargs_)
supermod.MMMMMMdataKind.subclass = MMMMMMdataKindSub
# end class MMMMMMdataKindSub


class dataTypeNNNMNNNSub(supermod.dataTypeNNNMNNN):
    def __init__(self, content1=None, **kwargs_):
        super(dataTypeNNNMNNNSub, self).__init__(content1,  **kwargs_)
supermod.dataTypeNNNMNNN.subclass = dataTypeNNNMNNNSub
# end class dataTypeNNNMNNNSub


def get_root_tag(node):
    tag = supermod.Tag_pattern_.match(node.tag).groups()[-1]
    rootClass = None
    rootClass = supermod.GDSClassesMapping.get(tag)
    if rootClass is None and hasattr(supermod, tag):
        rootClass = getattr(supermod, tag)
    return tag, rootClass


def parse(inFilename, silence=False):
    parser = None
    doc = parsexml_(inFilename, parser)
    rootNode = doc.getroot()
    rootTag, rootClass = get_root_tag(rootNode)
    if rootClass is None:
        rootTag = 'dataKind'
        rootClass = supermod.dataKind
    rootObj = rootClass.factory()
    rootObj.build(rootNode)
    # Enable Python to collect the space used by the DOM.
    doc = None
##     if not silence:
##         sys.stdout.write('<?xml version="1.0" ?>\n')
##         rootObj.export(
##             sys.stdout, 0, name_=rootTag,
##             namespacedef_='',
##             pretty_print=True)
    return rootObj


def parseEtree(inFilename, silence=False):
    parser = None
    doc = parsexml_(inFilename, parser)
    rootNode = doc.getroot()
    rootTag, rootClass = get_root_tag(rootNode)
    if rootClass is None:
        rootTag = 'dataKind'
        rootClass = supermod.dataKind
    rootObj = rootClass.factory()
    rootObj.build(rootNode)
    # Enable Python to collect the space used by the DOM.
    doc = None
    mapping = {}
    rootElement = rootObj.to_etree(None, name_=rootTag, mapping_=mapping)
    reverse_mapping = rootObj.gds_reverse_node_mapping(mapping)
##     if not silence:
##         content = etree_.tostring(
##             rootElement, pretty_print=True,
##             xml_declaration=True, encoding="utf-8")
##         sys.stdout.write(content)
##         sys.stdout.write('\n')
    return rootObj, rootElement, mapping, reverse_mapping


def parseString(inString, silence=False):
    if sys.version_info.major == 2:
        from StringIO import StringIO
    else:
        from io import BytesIO as StringIO
    parser = None
    doc = parsexml_(StringIO(inString), parser)
    rootNode = doc.getroot()
    rootTag, rootClass = get_root_tag(rootNode)
    if rootClass is None:
        rootTag = 'dataKind'
        rootClass = supermod.dataKind
    rootObj = rootClass.factory()
    rootObj.build(rootNode)
    # Enable Python to collect the space used by the DOM.
    doc = None
##     if not silence:
##         sys.stdout.write('<?xml version="1.0" ?>\n')
##         rootObj.export(
##             sys.stdout, 0, name_=rootTag,
##             namespacedef_='')
    return rootObj


def parseLiteral(inFilename, silence=False):
    parser = None
    doc = parsexml_(inFilename, parser)
    rootNode = doc.getroot()
    rootTag, rootClass = get_root_tag(rootNode)
    if rootClass is None:
        rootTag = 'dataKind'
        rootClass = supermod.dataKind
    rootObj = rootClass.factory()
    rootObj.build(rootNode)
    # Enable Python to collect the space used by the DOM.
    doc = None
##     if not silence:
##         sys.stdout.write('#from cleanupname2_sup import *\n\n')
##         sys.stdout.write('import cleanupname2_sup as model_\n\n')
##         sys.stdout.write('rootObj = model_.rootClass(\n')
##         rootObj.exportLiteral(sys.stdout, 0, name_=rootTag)
##         sys.stdout.write(')\n')
    return rootObj


USAGE_TEXT = """
Usage: python ???.py <infilename>
"""


def usage():
    print(USAGE_TEXT)
    sys.exit(1)


def main():
    args = sys.argv[1:]
    if len(args) != 1:
        usage()
    infilename = args[0]
    parse(infilename)


if __name__ == '__main__':
    #import pdb; pdb.set_trace()
    main()
